//
//  UserProfile.swift
//  FratRat
//

import Foundation
import UIKit

//
//  UserProfile.swift
//  FratRat
//

struct UserProfile: Equatable {
    var name: String = ""
    var college: String = ""
    var year: String = ""
    var bio: String = ""
    var email: String = ""
    var photoURLs: [String] = []         // blob IDs for uploaded photos
    var localPhotoFilenames: [String] = [] // on-disk JPEG filenames

    private static let localPhotosKey = "fratrat.localPhotoFilenames"
    private static let emailKey       = "fratrat.userEmail"

    // MARK: - Load from SQLite

    static func load() -> UserProfile {
        var profile = UserProfile()

        // Load core fields from SQLite via FFI
        if let p = loadUserProfile() {
            profile.name     = p.name
            profile.college  = p.college
            profile.year     = p.year
            profile.bio      = p.bio
            profile.photoURLs = p.photoBlobIds
        }

        // Local-only fields from UserDefaults
        profile.localPhotoFilenames = UserDefaults.standard
            .stringArray(forKey: localPhotosKey) ?? []
        profile.email = UserDefaults.standard.string(forKey: emailKey) ?? ""

        return profile
    }

    // MARK: - Save to SQLite

    func save() {
        let peerProfile = PeerProfile(
            peerId:       NodeIdentity.loadOrGenerateDefault().peerIdString(),
            name:         name,
            college:      college,
            year:         year,
            bio:          bio,
            photoBlobIds: photoURLs,
            timestamp:    UInt64(Date().timeIntervalSince1970)
        )
        let ok = saveUserProfile(profile: peerProfile)
        if !ok { print("[UserProfile] SQLite save failed") }

        UserDefaults.standard.set(localPhotoFilenames, forKey: Self.localPhotosKey)
        UserDefaults.standard.set(email, forKey: Self.emailKey)
    }

    // MARK: - Computed

    var isComplete: Bool {
        !name.trimmingCharacters(in: .whitespaces).isEmpty &&
        !college.trimmingCharacters(in: .whitespaces).isEmpty &&
        !year.isEmpty
    }

    var initials: String {
        let parts = name.split(separator: " ")
        let chars = parts.prefix(2).compactMap { $0.first }.map(String.init).joined()
        return chars.isEmpty ? "?" : chars.uppercased()
    }
}

// MARK: - Year options
enum SchoolYear: String, CaseIterable, Identifiable {
    case freshman   = "Freshman"
    case sophomore  = "Sophomore"
    case junior     = "Junior"
    case senior     = "Senior"
    case gradStudent = "Grad student"

    var id: String { rawValue }
}

// MARK: - ImageStore
// Local on-device storage for profile photos.
// Saves JPEGs to Documents/ProfilePhotos/ for fast display
// before/while mesh blob upload completes.
struct ImageStore {
    private static var directory: URL {
        let docs = FileManager.default.urls(for: .documentDirectory, in: .userDomainMask)[0]
        let dir  = docs.appendingPathComponent("ProfilePhotos", isDirectory: true)
        if !FileManager.default.fileExists(atPath: dir.path) {
            try? FileManager.default.createDirectory(
                at: dir,
                withIntermediateDirectories: true
            )
        }
        return dir
    }

    /// Save a UIImage to disk as JPEG. Returns filename (not full path).
    static func save(_ image: UIImage, quality: CGFloat = 0.8) -> String? {
        guard let data = image.jpegData(compressionQuality: quality) else { return nil }
        let filename = "\(UUID().uuidString).jpg"
        let url = directory.appendingPathComponent(filename)
        do {
            try data.write(to: url)
            return filename
        } catch {
            print("[ImageStore] save failed: \(error)")
            return nil
        }
    }

    /// Load a UIImage from a saved filename.
    static func load(_ filename: String) -> UIImage? {
        let url = directory.appendingPathComponent(filename)
        guard let data = try? Data(contentsOf: url) else { return nil }
        return UIImage(data: data)
    }

    /// Raw JPEG bytes for blob upload.
    static func data(for filename: String) -> Data? {
        let url = directory.appendingPathComponent(filename)
        return try? Data(contentsOf: url)
    }

    /// Delete a saved photo.
    static func delete(_ filename: String) {
        let url = directory.appendingPathComponent(filename)
        try? FileManager.default.removeItem(at: url)
    }
}

struct AppSettings: Codable {
    var appearance: AppearanceMode = .system
    var maxDistanceKm: Double = 50
    var blockedPeerIds: [String] = []

    // Legacy — kept for migration
    var darkMode: Bool {
        get { appearance == .dark }
        set { appearance = newValue ? .dark : .light }
    }

    static let key = "fratrat.appSettings"

    static func load() -> AppSettings {
        guard let data = UserDefaults.standard.data(forKey: key),
              let settings = try? JSONDecoder().decode(AppSettings.self, from: data)
        else { return AppSettings() }
        return settings
    }

    func save() {
        guard let data = try? JSONEncoder().encode(self) else { return }
        UserDefaults.standard.set(data, forKey: AppSettings.key)
        // Apply immediately to the app-wide preference
        UserDefaults.standard.set(appearance.rawValue, forKey: "appearanceMode")
    }
}
