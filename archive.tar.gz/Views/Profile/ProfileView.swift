//
//  ProfileView.swift
//  FratRat
//
//  Created by Brady Bangasser on 5/27/26.
//


//
//  ProfileView.swift
//  FratRat
//

import SwiftUI
import PhotosUI

struct ProfileView: View {
    @EnvironmentObject var mesh: MeshManager
    @State private var profile = UserProfile.load()
    @State private var selectedItems: [PhotosPickerItem] = []
    @State private var photos: [UIImage] = []
    @State private var showSaved = false

    var body: some View {
        ZStack {
            Color.fratBg.ignoresSafeArea()

            ScrollView {
                VStack(alignment: .leading, spacing: 0) {

                    // ── Header ────────────────────────────────────────────────
                    HStack {
                        VStack(alignment: .leading, spacing: 4) {
                            Text("Profile")
                                .font(.system(size: 34, weight: .black))
                                .foregroundColor(.fratDark)
                            Text("Show off your vibe.")
                                .font(.fratBody(15))
                                .foregroundColor(.fratGray)
                        }
                        Spacer()

                        // Save indicator
                        if showSaved {
                            Label("Saved", systemImage: "checkmark.circle.fill")
                                .font(.fratSemi(13))
                                .foregroundColor(.green)
                                .transition(.opacity)
                        }
                    }
                    .padding(.horizontal, 24)
                    .padding(.top, 60)
                    .padding(.bottom, 24)

                    // ── Photos ────────────────────────────────────────────────
                    VStack(alignment: .leading, spacing: 12) {
                        SectionLabel("PHOTOS")
                            .padding(.horizontal, 24)

                        PhotoGrid(photos: $photos, selectedItems: $selectedItems)
                            .padding(.horizontal, 24)
                    }
                    .padding(.bottom, 24)

                    // ── Fields ────────────────────────────────────────────────
                    VStack(spacing: 20) {
                        ProfileField(label: "NAME", placeholder: "Your name", value: $profile.name)
                        ProfileField(label: "COLLEGE", placeholder: "Your college", value: $profile.college)
                        ProfileField(label: "YEAR", placeholder: "Freshman / Sophomore / Junior / Senior", value: $profile.year)
                        ProfileField(label: "BIO", placeholder: "Tell people about yourself…", value: $profile.bio, multiline: true)
                    }
                    .padding(.horizontal, 24)

                    // ── Peer ID ───────────────────────────────────────────────
                    if let peerId = mesh.myPeerId {
                        VStack(alignment: .leading, spacing: 8) {
                            SectionLabel("MESH IDENTITY")
                            HStack {
                                Text(peerId)
                                    .font(.system(size: 12, design: .monospaced))
                                    .foregroundColor(.fratGray)
                                    .lineLimit(1)
                                    .truncationMode(.middle)
                                Spacer()
                                Button {
                                    UIPasteboard.general.string = peerId
                                } label: {
                                    Image(systemName: "doc.on.doc")
                                        .font(.system(size: 14))
                                        .foregroundColor(.fratPink)
                                }
                            }
                            .padding(12)
                            .background(RoundedRectangle(cornerRadius: 12).fill(Color.white))
                        }
                        .padding(.horizontal, 24)
                        .padding(.top, 8)
                    }

                    // ── Save button ───────────────────────────────────────────
                    Button {
                        saveProfile()
                    } label: {
                        Text("Save profile")
                            .font(.fratBold(17))
                            .foregroundColor(.white)
                            .frame(maxWidth: .infinity)
                            .padding(.vertical, 18)
                            .background(
                                RoundedRectangle(cornerRadius: 16)
                                    .fill(Color.fratPink)
                            )
                    }
                    .padding(.horizontal, 24)
                    .padding(.top, 32)
                    .padding(.bottom, 120)
                }
            }
        }
        .onChange(of: selectedItems) { items in
            loadPhotos(from: items)
        }
    }

    private func saveProfile() {
        profile.save()
        withAnimation {
            showSaved = true
        }
        DispatchQueue.main.asyncAfter(deadline: .now() + 2) {
            withAnimation { showSaved = false }
        }
    }

    private func loadPhotos(from items: [PhotosPickerItem]) {
        Task {
            var loaded: [UIImage] = []
            for item in items {
                if let data = try? await item.loadTransferable(type: Data.self),
                   let image = UIImage(data: data) {
                    loaded.append(image)
                }
            }
            await MainActor.run {
                photos = loaded
            }
        }
    }
}

// MARK: - Photo grid
private struct PhotoGrid: View {
    @Binding var photos: [UIImage]
    @Binding var selectedItems: [PhotosPickerItem]

    private let columns = [
        GridItem(.flexible()),
        GridItem(.flexible()),
        GridItem(.flexible())
    ]

    var body: some View {
        LazyVGrid(columns: columns, spacing: 8) {
            // Existing photos
            ForEach(Array(photos.enumerated()), id: \.offset) { index, photo in
                ZStack(alignment: .topTrailing) {
                    Image(uiImage: photo)
                        .resizable()
                        .scaledToFill()
                        .frame(height: 110)
                        .clipShape(RoundedRectangle(cornerRadius: 14))

                    Button {
                        photos.remove(at: index)
                    } label: {
                        Image(systemName: "xmark")
                            .font(.system(size: 10, weight: .bold))
                            .foregroundColor(.white)
                            .frame(width: 22, height: 22)
                            .background(Circle().fill(Color.black.opacity(0.7)))
                    }
                    .padding(6)
                }
            }

            // Add photo slot (up to 6)
            if photos.count < 6 {
                PhotosPicker(
                    selection: $selectedItems,
                    maxSelectionCount: 6 - photos.count,
                    matching: .images
                ) {
                    ZStack {
                        RoundedRectangle(cornerRadius: 14)
                            .fill(Color.white)
                            .frame(height: 110)
                            .overlay(
                                RoundedRectangle(cornerRadius: 14)
                                    .strokeBorder(
                                        Color.gray.opacity(0.2),
                                        style: StrokeStyle(lineWidth: 1.5, dash: [5])
                                    )
                            )
                        VStack(spacing: 6) {
                            Image(systemName: "plus")
                                .font(.system(size: 20, weight: .medium))
                                .foregroundColor(.fratGray)
                            Text("Add photo")
                                .font(.fratBody(11))
                                .foregroundColor(.fratGray)
                        }
                    }
                }
            }
        }
    }
}

// MARK: - Profile field
private struct ProfileField: View {
    let label: String
    let placeholder: String
    @Binding var value: String
    var multiline: Bool = false

    var body: some View {
        VStack(alignment: .leading, spacing: 8) {
            Text(label)
                .font(.fratSemi(11))
                .foregroundColor(.fratGray)

            if multiline {
                ZStack(alignment: .topLeading) {
                    if value.isEmpty {
                        Text(placeholder)
                            .font(.fratBody(15))
                            .foregroundColor(.fratGray.opacity(0.6))
                            .padding(.horizontal, 14)
                            .padding(.top, 12)
                    }
                    TextEditor(text: $value)
                        .font(.fratBody(15))
                        .foregroundColor(.fratDark)
                        .frame(minHeight: 90)
                        .padding(.horizontal, 10)
                        .padding(.vertical, 8)
                        .scrollContentBackground(.hidden)
                }
                .background(RoundedRectangle(cornerRadius: 14).fill(Color.white))
            } else {
                TextField(placeholder, text: $value)
                    .font(.fratBody(15))
                    .foregroundColor(.fratDark)
                    .padding(.horizontal, 14)
                    .padding(.vertical, 13)
                    .background(RoundedRectangle(cornerRadius: 14).fill(Color.white))
            }
        }
    }
}

// MARK: - Section label
private struct SectionLabel: View {
    let text: String
    init(_ text: String) { self.text = text }
    var body: some View {
        Text(text)
            .font(.fratSemi(11))
            .foregroundColor(.fratGray)
    }
}

#Preview {
    ProfileView()
        .environmentObject(MeshManager())
}