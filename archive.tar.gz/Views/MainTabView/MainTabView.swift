//
//  MainTabView.swift
//  FratRat
//

import SwiftUI

enum Tab {
    case discover, messages, parties, profile, settings
}

struct MainTabView: View {
    @State private var selectedTab: Tab = .discover

    var body: some View {
        ZStack(alignment: .bottom) {
            // Tab content — no TabView so we control the bar fully
            Group {
                switch selectedTab {
                case .discover:
                    DiscoverView()
                case .messages:
                    MatchesView()
                case .parties:
                    PartiesView()
                case .profile:
                    ProfileView()
                case .settings:
                    SettingsView()
                }
            }
            .frame(maxWidth: .infinity, maxHeight: .infinity)

            // Custom tab bar
            CustomTabBar(selectedTab: $selectedTab)
        }
        .ignoresSafeArea(edges: .bottom)
    }
}

// MARK: - Custom tab bar
struct CustomTabBar: View {
    @Binding var selectedTab: Tab

    private let items: [(tab: Tab, icon: String, label: String)] = [
        (.discover, "flame.fill",    "Discover"),
        (.messages,  "message.fill",  "Messages"),
        (.parties,  "music.note",    "Parties"),
        (.profile,  "person.fill",   "Profile"),
        (.settings, "gearshape.fill","Settings"),
    ]

    var body: some View {
        HStack(spacing: 0) {
            ForEach(items, id: \.label) { item in
                Button {
                    selectedTab = item.tab
                } label: {
                    VStack(spacing: 4) {
                        Image(systemName: item.icon)
                            .font(.system(size: 22, weight: .medium))
                        Text(item.label)
                            .font(.system(size: 10, weight: .medium))
                    }
                    .foregroundColor(selectedTab == item.tab ? .fratPink : Color.gray.opacity(0.6))
                    .frame(maxWidth: .infinity)
                    .padding(.top, 12)
                    .padding(.bottom, 28)
                }
            }
        }
        .background(Color.fratDark)
    }
}

// MARK: - Placeholder views (replace with real implementations)


#Preview {
    MainTabView()
        .environmentObject(MeshManager())
}
