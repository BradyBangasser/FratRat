//
//  MeshImage.swift
//  FratRat
//
//  Created by Brady Bangasser on 6/16/26.
//
import SwiftUI
import Combine

// MARK: - MeshImage
struct MeshImage: View {
    var blobId: String?
    var localFilename: String?
    var initials: String = "?"
    var size: CGFloat = 54
    var cornerRadius: CGFloat? = nil  // nil = square with default radius
    var contentMode: ContentMode = .fill

    @EnvironmentObject private var mesh: MeshManager
    @StateObject private var loader = ImageLoader()

    private var radius: CGFloat {
        cornerRadius ?? size / 4
    }

    var body: some View {
        ZStack {
            if let image = loader.image {
                Image(uiImage: image)
                    .resizable()
                    .aspectRatio(contentMode: contentMode)
                    .frame(width: size, height: size)
                    .clipped()
            } else {
                // Initials placeholder — shown while loading or if no photo
                InitialsAvatar(initials: initials, size: size)
            }

            // Loading indicator overlay
            if loader.isLoading {
                ZStack {
                    Color.black.opacity(0.3)
                    ProgressView()
                        .tint(.white)
                        .scaleEffect(0.8)
                }
            }
        }
        .frame(width: size, height: size)
        .clipShape(RoundedRectangle(cornerRadius: radius, style: .continuous))
        .task(id: blobId ?? localFilename ?? "") {
            await loader.load(
                blobId: blobId,
                localFilename: localFilename,
                mesh: mesh
            )
        }
    }
}

// MARK: - Circle convenience
extension MeshImage {
    static func circle(
        blobId: String? = nil,
        localFilename: String? = nil,
        initials: String = "?",
        size: CGFloat = 54
    ) -> MeshImage {
        MeshImage(
            blobId: blobId,
            localFilename: localFilename,
            initials: initials,
            size: size,
            cornerRadius: size / 2
        )
    }
}

// MARK: - ImageLoader
// Observable loader so MeshImage re-renders when the image arrives.
// Caches in memory so repeated renders of the same blob don't re-fetch.
@MainActor
class ImageLoader: ObservableObject {
    @Published var image: UIImage? = nil
    @Published var isLoading = false

    private static var cache: [String: UIImage] = [:]

    func load(blobId: String?, localFilename: String?, mesh: MeshManager) async {
        image = nil

        // 1. Local file — instant
        if let filename = localFilename, !filename.isEmpty {
            if let img = ImageStore.load(filename) {
                image = img
                return
            }
        }

        // 2. Blob ID — check memory cache first, then fetch from mesh
        if let id = blobId, !id.isEmpty {
            if let cached = Self.cache[id] {
                image = cached
                return
            }

            isLoading = true
            defer { isLoading = false }

            do {
                let data = try await mesh.retrievePhoto(blobId: id)
                if let img = UIImage(data: data) {
                    Self.cache[id] = img
                    image = img
                }
            } catch {
                // Blob not available yet — initials fallback stays
            }
        }
    }

    /// Clear the in-memory cache (e.g. on memory warning).
    static func clearCache() {
        cache.removeAll()
    }
}

// MARK: - InitialsAvatar
// Gradient circle/square showing initials — used as fallback
// and as the avatar for peers with no photo.
struct InitialsAvatar: View {
    let initials: String
    let size: CGFloat
    var cornerRadius: CGFloat? = nil
    var colors: [Color] = [.fratPink, Color(red: 0.8, green: 0.2, blue: 0.5)]

    private var radius: CGFloat {
        cornerRadius ?? size / 2
    }

    var body: some View {
        ZStack {
            RoundedRectangle(cornerRadius: radius, style: .continuous)
                .fill(
                    LinearGradient(
                        colors: colors,
                        startPoint: .topLeading,
                        endPoint: .bottomTrailing
                    )
                )
            Text(initials.prefix(2).uppercased())
                .font(.system(size: size * 0.35, weight: .bold, design: .rounded))
                .foregroundColor(.white)
        }
        .frame(width: size, height: size)
    }
}

#Preview {
    VStack(spacing: 20) {
        // Circle avatar (typical use)
        MeshImage.circle(initials: "BJ", size: 54)

        // Square card photo
        MeshImage(initials: "AB", size: 120, cornerRadius: 16)

        // Initials only
        InitialsAvatar(initials: "CD", size: 44)
    }
    .padding()
    .environmentObject(MeshManager())
}
