import SwiftUI

// MARK: - Appearance mode
enum AppearanceMode: String, Codable {
    case light
    case dark
    case system

    var colorScheme: ColorScheme? {
        switch self {
        case .light:  return .light
        case .dark:   return .dark
        case .system: return nil
        }
    }

    var label: String {
        switch self {
        case .light:  return "Light"
        case .dark:   return "Dark"
        case .system: return "System"
        }
    }

    var icon: String {
        switch self {
        case .light:  return "sun.max.fill"
        case .dark:   return "moon.fill"
        case .system: return "circle.lefthalf.filled"
        }
    }
}

// MARK: - Brand colors
extension Color {
    // Fixed colors — same in light and dark
    static let fratPink      = Color(red: 0.98, green: 0.27, blue: 0.49)
    static let fratPinkLight = Color(red: 0.98, green: 0.27, blue: 0.49).opacity(0.12)

    // Adaptive — automatically switch with color scheme
    static let fratBg   = Color(UIColor { trait in
        trait.userInterfaceStyle == .dark
            ? UIColor(red: 0.11, green: 0.11, blue: 0.13, alpha: 1)
            : UIColor(red: 0.94, green: 0.94, blue: 0.96, alpha: 1)
    })

    static let fratCard = Color(UIColor { trait in
        trait.userInterfaceStyle == .dark
            ? UIColor(red: 0.18, green: 0.18, blue: 0.20, alpha: 1)
            : UIColor.white
    })

    static let fratDark = Color(UIColor { trait in
        trait.userInterfaceStyle == .dark
            ? UIColor(red: 0.95, green: 0.95, blue: 0.97, alpha: 1)
            : UIColor(red: 0.11, green: 0.11, blue: 0.12, alpha: 1)
    })

    static let fratGray = Color(UIColor { trait in
        trait.userInterfaceStyle == .dark
            ? UIColor(red: 0.65, green: 0.65, blue: 0.68, alpha: 1)
            : UIColor(red: 0.55, green: 0.55, blue: 0.58, alpha: 1)
    })
}

// MARK: - Typography
extension Font {
    static func fratBlack(_ size: CGFloat) -> Font { .system(size: size, weight: .black) }
    static func fratBold(_ size: CGFloat)  -> Font { .system(size: size, weight: .bold) }
    static func fratSemi(_ size: CGFloat)  -> Font { .system(size: size, weight: .semibold) }
    static func fratBody(_ size: CGFloat)  -> Font { .system(size: size, weight: .regular) }
}
